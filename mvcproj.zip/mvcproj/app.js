const express = require('express');
const path = require('path');
const { sequelize, User, Account, Operation } = require('./models');
const routes = require('./routes');

const app = express();

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(express.urlencoded({ extended: false }));
app.use('/public', express.static(path.join(__dirname, 'public')));

app.use('/', routes);

const PORT = process.env.PORT || 5000;

if (require.main === module) {
  // start server
  sequelize.authenticate()
    .then(() => console.log('Database connected'))
    .catch(err => console.error('DB connection error', err));

  app.listen(PORT, () => {
    console.log(`Server running on http://127.0.0.1:${PORT}`);
  });
}

module.exports = app;
