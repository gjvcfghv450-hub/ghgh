const { sequelize, User, Account } = require('./models');

async function init() {
  try {
    await sequelize.sync({ force: true });
    console.log('Database synced (force: true)');

    const alice = await User.create({ name: 'alice' });
    const bob = await User.create({ name: 'bob' });

    await Account.create({ name: 'Alice Wallet', balance: 1000, userId: alice.id });
    await Account.create({ name: 'Bob Wallet', balance: 500, userId: bob.id });

    console.log('Sample users and accounts created.');
    process.exit(0);
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
}

init();
