const express = require('express');
const router = express.Router();
const { sequelize, User, Account, Operation } = require('./models');

// Home - list accounts and operations
router.get('/', async (req, res) => {
  const users = await User.findAll({ include: Account });
  const accounts = await Account.findAll({ include: User });
  const operations = await Operation.findAll({ order: [['createdAt', 'DESC']], limit: 50, include: [{ model: Account, as: 'fromAccount' }, { model: Account, as: 'toAccount' }] });
  res.render('index', { users, accounts, operations });
});

// Create user
router.post('/users', async (req, res) => {
  const { name } = req.body;
  if (!name) return res.redirect('/');
  try { await User.create({ name }); } catch (e) { console.error(e); }
  res.redirect('/');
});

// Create account
router.post('/accounts', async (req, res) => {
  const { name, userId, balance } = req.body;
  try { await Account.create({ name, userId, balance: parseFloat(balance) || 0 }); } catch (e) { console.error(e); }
  res.redirect('/');
});

// Deposit
router.post('/deposit', async (req, res) => {
  const { accountId, amount, description } = req.body;
  const t = await sequelize.transaction();
  try {
    const acct = await Account.findByPk(accountId, { transaction: t, lock: t.LOCK.UPDATE });
    const amt = parseFloat(amount);
    if (!acct || amt <= 0) throw new Error('Invalid');
    acct.balance = acct.balance + amt;
    await acct.save({ transaction: t });
    await Operation.create({ type: 'deposit', amount: amt, toAccountId: acct.id, description }, { transaction: t });
    await t.commit();
  } catch (err) {
    await t.rollback();
    console.error(err);
  }
  res.redirect('/');
});

// Purchase (withdraw)
router.post('/purchase', async (req, res) => {
  const { accountId, amount, description } = req.body;
  const t = await sequelize.transaction();
  try {
    const acct = await Account.findByPk(accountId, { transaction: t, lock: t.LOCK.UPDATE });
    const amt = parseFloat(amount);
    if (!acct || amt <= 0 || acct.balance < amt) throw new Error('Invalid or insufficient funds');
    acct.balance = acct.balance - amt;
    await acct.save({ transaction: t });
    await Operation.create({ type: 'purchase', amount: amt, fromAccountId: acct.id, description }, { transaction: t });
    await t.commit();
  } catch (err) {
    await t.rollback();
    console.error(err);
  }
  res.redirect('/');
});

// Transfer
router.post('/transfer', async (req, res) => {
  const { fromAccountId, toAccountId, amount, description } = req.body;
  const t = await sequelize.transaction();
  try {
    if (fromAccountId === toAccountId) throw new Error('Same account');
    const from = await Account.findByPk(fromAccountId, { transaction: t, lock: t.LOCK.UPDATE });
    const to = await Account.findByPk(toAccountId, { transaction: t, lock: t.LOCK.UPDATE });
    const amt = parseFloat(amount);
    if (!from || !to || amt <= 0 || from.balance < amt) throw new Error('Invalid transfer');
    from.balance = from.balance - amt;
    to.balance = to.balance + amt;
    await from.save({ transaction: t });
    await to.save({ transaction: t });
    await Operation.create({ type: 'transfer', amount: amt, fromAccountId: from.id, toAccountId: to.id, description }, { transaction: t });
    await t.commit();
  } catch (err) {
    await t.rollback();
    console.error(err);
  }
  res.redirect('/');
});

module.exports = router;
