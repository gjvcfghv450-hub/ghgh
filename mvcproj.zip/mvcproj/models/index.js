const { Sequelize, DataTypes } = require('sequelize');
const path = require('path');

const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: path.join(__dirname, '..', 'finance.db'),
  logging: false,
});

const User = require('./user')(sequelize, DataTypes);
const Account = require('./account')(sequelize, DataTypes);
const Operation = require('./operation')(sequelize, DataTypes);

// Associations
User.hasMany(Account, { foreignKey: 'userId' });
Account.belongsTo(User, { foreignKey: 'userId' });

Account.hasMany(Operation, { as: 'outgoingOps', foreignKey: 'fromAccountId' });
Account.hasMany(Operation, { as: 'incomingOps', foreignKey: 'toAccountId' });
Operation.belongsTo(Account, { as: 'fromAccount', foreignKey: 'fromAccountId' });
Operation.belongsTo(Account, { as: 'toAccount', foreignKey: 'toAccountId' });

module.exports = { sequelize, User, Account, Operation };
