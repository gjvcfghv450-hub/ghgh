module.exports = (sequelize, DataTypes) => {
  const Operation = sequelize.define('Operation', {
    type: { type: DataTypes.STRING, allowNull: false }, // deposit, purchase, transfer
    amount: { type: DataTypes.FLOAT, allowNull: false },
    description: { type: DataTypes.STRING, allowNull: true }
  }, { tableName: 'operations' });

  return Operation;
};
